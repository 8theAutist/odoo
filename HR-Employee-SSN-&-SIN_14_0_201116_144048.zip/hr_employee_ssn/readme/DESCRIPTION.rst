This module allows to use employee's SSN & SIN fields by exposing them in the user interface.
